# V8.2 engineering notes

## Baseline and scope

- Base is the exact V8 code from `oval-ghost-v8.zip`.
- Team-reported best scored result remains V8 at **2.92**.
- V8.2 changes only projectile-threat handling and beam-threat attribution. It does not include the V8.1 zone/drop/target-selection policy changes or V9's ContextSteering/A* rewrite.

## Corrections

### 1. Mortar impact and splash visibility

V8's mortar CPA sampled the ballistic shell trajectory and used its closest approach, but did not stop the trajectory at the first terrain or solid-prism collision. This could cause a dodge when a shell would first hit a wall or the ground elsewhere. V8.2 samples the short danger horizon in 50 ms steps, finds the first blocking fraction on each segment, estimates the impact time/position, and tests splash line of sight. For a wall impact, the visibility test starts just before the wall surface so a same-side blast is not incorrectly treated as fully hidden by the wall.

The ballistic sweep and map ray test are approximations, not an exact reproduction of the server's collision integrator. If no impact is found in the short 0.9 s horizon, the bot falls back to closest approach on the visible shell path and recomputes the geometry at the interpolated time.

### 2. Beam source attribution

V8 recorded the source bearing for every visible laser/lightning beam, even though the protocol makes a beam observable when either end or any middle segment is in view. A distant shooter could therefore be treated as the local threat even when the beam path was nowhere near us. V8.2 measures distance from our mech to every consecutive path segment and records the source only if the nearest segment is within 35 m. The source bearing is still used as directional evidence; this does not itself trigger a dodge.

## Known uncertainties

- No gameplay-score improvement is claimed; only a scored practice run can establish that.
- Local protocol-checker timing and synthetic stress timings are not measurements from the competition's 1-CPU Docker sandbox.
- Docker build/run was not performed in this environment because Docker is unavailable.
- The gun-projectile shooter-velocity inheritance question remains unresolved and unchanged from V8.
