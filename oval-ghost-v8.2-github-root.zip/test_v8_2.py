"""Focused regression tests for the narrow V8.2 safety corrections."""
import math
import os
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / "bot.py").read_text(encoding="utf-8")
source = source.rsplit("\nmf.run(Bot)", 1)[0] + "\n"
namespace = {"__name__": "v8_2_test_module"}
exec(compile(source, str(ROOT / "bot.py"), "exec"), namespace)
Bot = namespace["Bot"]


def make_bot():
    b = Bot.__new__(Bot)
    b.cfg = {
        "weapons": {"mortar": {"gravity": 22.0, "splash_radius": 7.0}},
        "projectile": {"gun_radius": 0.3, "npc_radius": 0.3},
        "mech": {"height": 9.0, "radius": 2.5},
    }
    b.last_threat_t = -999.0
    b.last_threat_bearing = None
    b.last_attacker_bearing = None
    b.last_threat_kind = None
    b.last_threat_dist = "far"
    b.last_attacker_id = None
    return b


class TestV82Corrections(unittest.TestCase):
    def test_distant_beam_is_not_misremembered_as_attacker(self):
        b = make_bot()
        me = {"id": 0, "pos": [0.0, 0.0, 0.0]}
        obs = {"beams": [{
            "by": 7, "kind": "laser", "age": 0.1,
            "path": [[120.0, 120.0, 8.0], [200.0, 200.0, 8.0]],
        }]}
        b._remember_beams(obs, me, 10.0)
        self.assertIsNone(b.last_threat_bearing)
        self.assertIsNone(b.last_attacker_id)

    def test_lightning_later_chain_segment_can_track_nearby_threat(self):
        b = make_bot()
        me = {"id": 0, "pos": [0.0, 0.0, 0.0]}
        obs = {"beams": [{
            "by": 7, "kind": "lightning", "age": 0.1,
            "path": [[120.0, 120.0, 8.0], [80.0, 60.0, 6.0],
                     [5.0, 2.0, 5.0], [-40.0, 30.0, 4.0]],
        }]}
        b._remember_beams(obs, me, 10.0)
        self.assertEqual(b.last_attacker_id, 7)
        self.assertEqual(b.last_threat_kind, "lightning")
        self.assertAlmostEqual(b.last_threat_t, 9.9)

    def test_own_beam_is_ignored(self):
        b = make_bot()
        me = {"id": 0, "pos": [0.0, 0.0, 0.0]}
        obs = {"beams": [{
            "by": 0, "kind": "laser", "age": 0.1,
            "path": [[10.0, 0.0, 8.0], [100.0, 0.0, 8.0]],
        }]}
        b._remember_beams(obs, me, 10.0)
        self.assertIsNone(b.last_threat_bearing)

    @staticmethod
    def _wall_model(b):
        b._terrain_height = lambda x, y: 0.0
        def blocked(a, q):
            return ((float(a[0]) - 10.0) * (float(q[0]) - 10.0) <= 0.0
                    and abs(float(a[0]) - float(q[0])) > 1e-6)
        b._ray_blocked = blocked

    def test_mortar_wall_impact_same_side_splash_is_a_threat(self):
        b = make_bot()
        self._wall_model(b)
        projectile = {"kind": "mortar", "pos": [20.0, 0.0, 5.0],
                      "vel": [-40.0, 0.0, -2.0]}
        me = {"pos": [14.0, 0.0, 0.0], "vel": [0.0, 0.0, 0.0],
              "stats": {"height": 9.0, "radius": 2.5}, "grounded": True}
        _, urgent, _ = b._incoming_threat({"projectiles": [projectile]}, me)
        self.assertTrue(urgent)

    def test_mortar_wall_blocks_splash_on_opposite_side(self):
        b = make_bot()
        self._wall_model(b)
        projectile = {"kind": "mortar", "pos": [20.0, 0.0, 5.0],
                      "vel": [-40.0, 0.0, -2.0]}
        me = {"pos": [4.0, 0.0, 0.0], "vel": [0.0, 0.0, 0.0],
              "stats": {"height": 9.0, "radius": 2.5}, "grounded": True}
        _, urgent, _ = b._incoming_threat({"projectiles": [projectile]}, me)
        self.assertFalse(urgent)


    def test_mortar_bridge_impact_uses_real_arena_geometry(self):
        arena = Path(os.environ.get("ARENA_DIR", "/mnt/data/arena_extracted/arena"))
        if not (arena / "v2" / "world.json").exists():
            self.skipTest("set ARENA_DIR to the supplied arena for map-backed test")
        b = Bot({
            "type": "hello", "protocol": "mechfight/1", "slot": 0, "seed": 3,
            "map": {"dir": str(arena), "files": ["v2/world.json", "v2/terrain.i16"]},
            "config": {"weapons": {"mortar": {"gravity": 22.0, "splash_radius": 7.0}},
                       "mech": {"height": 9.0, "radius": 2.5}},
        })
        # Supplied map bridge #0 spans x=-435.5..-414.9 and y=-60.3..-52.9.
        # This shell crosses its south edge; our mech is on the same side.
        ground = b._terrain_height(-425.2, -64.0)
        self.assertIsNotNone(ground)
        projectile = {"kind": "mortar", "pos": [-425.2, -64.3, -0.71],
                      "vel": [0.0, 72.0, 0.0]}
        me = {"pos": [-425.2, -64.0, ground], "vel": [0.0, 0.0, 0.0],
              "stats": {"height": 9.0, "radius": 2.5}, "grounded": True}
        _, urgent, _ = b._incoming_threat({"projectiles": [projectile]}, me)
        self.assertTrue(urgent)

    def test_mortar_ground_impact_predicts_splash_threat(self):
        b = make_bot()
        b._terrain_height = lambda x, y: 0.0
        b._ray_blocked = lambda a, q: False
        projectile = {"kind": "mortar", "pos": [20.0, 0.0, 5.0],
                      "vel": [-20.0, 0.0, -2.0]}
        me = {"pos": [10.0, 0.0, 0.0], "vel": [0.0, 0.0, 0.0],
              "stats": {"height": 9.0, "radius": 2.5}, "grounded": True}
        _, urgent, _ = b._incoming_threat({"projectiles": [projectile]}, me)
        self.assertTrue(urgent)


if __name__ == "__main__":
    unittest.main(verbosity=2)
