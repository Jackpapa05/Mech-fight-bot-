# Oval Ghost V8.2 — narrow safety/awareness candidate

V8.2 is built directly on the team's best-scoring V8 strategy. The reported V8 practice score is **2.92**. V8.2 has not yet received a scored practice submission, so 2.92 remains the result to beat.

## Changes from V8

1. **Mortar impact-aware dodging.** The short ballistic prediction now stops at the first terrain or solid-prism collision. It estimates the impact point and checks whether the blast has line of sight to the mech. This avoids reacting to a shell that hits a wall on the other side, while still reacting to a dangerous same-side wall or ground impact.
2. **Beam proximity filtering.** A laser or lightning beam is now treated as threat-direction evidence only when one of its path segments passes within 35 m of our mech. Every lightning chain segment is checked, because the shooter may be distant while a later chain segment passes nearby. Own-source beams are ignored defensively.
3. **No broad strategy rewrite.** V8.2 retains V8's zone, loot, weapon, target selection, cover, aiming, and steering policies. The intent is to fix two local perception/safety errors without repeating the much riskier V9 navigation rewrite.

## Validation

Run:

```sh
python3 test_v8.py
ARENA_DIR=/path/to/arena python3 -m unittest -v test_v8_2
python3 check/check.py --map-dir /path/to/arena -- python3 -u bot.py
```

`test_v8_2.py` includes a map-backed bridge-impact test when the supplied arena is available. `test_v8.py` retains V8's four focused regression tests.

## Submission advice

Treat V8.2 as an experiment, not as a proven improvement. Submit it for a scored practice run, compare its score against **2.92**, and keep V8 selected unless V8.2 beats that score. The protocol checker validates response timing and format; it does not simulate gameplay or predict placement.
