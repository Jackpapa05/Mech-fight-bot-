# V8.2 validation record

## Scored baseline

The team's screenshot shows V8 at **2.92** as the best scored submission, followed by V8.1 at 2.73. V8.2 has not yet been scored.

## Focused regression tests

- V8's original 4 focused tests pass.
- V8.2 adds 7 tests: distant beam rejection, later lightning-chain segment detection, own-beam rejection, same-side wall splash, opposite-side wall occlusion, ground-impact splash, and an impact test using the supplied arena's actual bridge/terrain geometry.
- Result: **11 focused tests passed** (4 + 7).

## Official protocol checker

Command:

```sh
python3 /path/to/mechfight-kit/check/check.py --map-dir /path/to/arena -- python3 -u bot.py
```

Local result:

- 300 / 300 observations answered
- 0 missed 50 ms deadlines; 0 late answers
- 0 wrong ticks; 0 malformed protocol lines
- 300 debug drawings; 0 over caps
- Response time: p50 **0.7 ms**, p90 **1.2 ms**, p99 **1.8 ms**, max **2.0 ms**
- Result: **PASS**

These are local machine timings, not the competition's 1-CPU match container.

## Synthetic stress timing

A local `act()` microbenchmark with a loaded arena, 15 visible mech opponents, 50 mortar projectiles, and a low-health state that activates cover selection measured over 30 repeated calls:

- p50 **12.76 ms**
- p90 **13.34 ms**
- max **13.58 ms**

This is a synthetic Python microbenchmark, not a gameplay simulation or Docker measurement.

## Not yet verified

- No 48-match practice score for V8.2.
- No Docker build/run in this environment.
- No claim that the score will exceed V8's 2.92. Keep V8 as final unless the scored V8.2 result is higher.
