#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$HERE"
python3 test_v8.py
python3 -m unittest -v test_v8_2
