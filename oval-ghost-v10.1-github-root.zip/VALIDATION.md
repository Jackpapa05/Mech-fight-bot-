# V10.1 validation

Validation performed in the local working environment:

- Python bytecode compilation: pass.
- Official protocol checker against the supplied 300-observation stream and extracted arena: **PASS**; 300/300 responses, zero missed 50 ms deadlines, zero wrong ticks, zero bad lines.
- Checker latency on this machine: p50 0.7 ms, p90 1.4 ms, p99 2.7 ms, max 4.6 ms.
- Synthetic stress test with 15 visible mechs, 40 projectiles (including 10 mortars), beams, and the real `world.json` / `terrain.i16`: p50 10.496 ms, p90 11.291 ms, p99 12.347 ms, max 15.164 ms.
- These timings are machine-specific, not official 1-CPU Docker-container measurements. The stress test is not a game simulation and cannot predict placement.
- No Docker image build was run because Docker is unavailable in this environment.

A real 48-match practice evaluation is still required before comparing V10.1 with the V8 score of 2.92.
