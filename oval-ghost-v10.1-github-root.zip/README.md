# Oval Ghost V10.1 Survival

A conservative V10 candidate built from the uploaded V10 `bot.py`.

## What changed from the uploaded V10

One safety-only adjustment: the laser-vs-lightning engagement gate is restored to V8's original rule. The bot only starts/continues the laser engagement branch when the target is beyond 38 m **and** no visible lightning-equipped mech is within 65 m. This avoids beginning a 0.75 s charge while a lightning opponent can close into its 45 m range and short the laser.

All other V10 behavior is retained: beam-polyline filtering, terrain-aware mortar threat sampling, target weighting, opportunistic reload, movement/retreat logic, cover logic, zone logic, and steering.

## Files

- `bot.py` — bot implementation
- `mechfight.py` — competition protocol helper
- `Dockerfile` — competition-style runner

Build locally with `docker build -t oval-ghost-v10.1 .` where Docker is available.
